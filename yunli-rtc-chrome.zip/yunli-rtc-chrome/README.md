设置 Chrome 启动参数：
 --args --user-data-dir=/Users/yunli/chrome_dev_test --disable-web-security --start-maximized --whitelisted-extension-id=deiphkofhmjigimedjjgfdjeflpomlch

Mac快捷方式：
chmod a+x chrome.command

Windows快捷方式：
powershell "$s=(New-Object -COM WScript.Shell).CreateShortcut('%userprofile%\Start Menu\Programs\Startup\%~n0.lnk');$s.TargetPath='%~f0';$s.Save()"
