$(function () {
  $('#record').click(function () {
    // chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], function () {});
    // chrome.tabCapture.getMediaStreamId({}, function (stream) {
    //   console.log(stream, 999);
    // });
    // chrome.tabCapture.capture({ audio: true, video: true }, function (stream) {
    //   console.log(stream, 999);
    // });

    chrome.tabCapture.capture({ video: true }, (stream) => {
      console.log(stream, 999);
    });
  });
  // var state = $("#state");
  // $("#send").click(function () {
  //   //给对象绑定事件
  //   chrome.tabs.query({ active: true, currentWindow: true }, function (tab) {
  //     //获取当前tab
  //     //向tab发送请求
  //     chrome.tabs.sendMessage(
  //       tab[0].id,
  //       {
  //         action: "send",
  //         keyword: $("#keyword").val(),
  //       },
  //       function (response) {
  //         console.log(response);
  //         state.html(response.state);
  //       }
  //     );
  //   });
  // });
  // $("#submit").click(function () {
  //   chrome.desktopCapture.chooseDesktopMedia(["screen"], function () {});
  //   chrome.tabs.query({active:true, currentWindow:true}, function (tab) {
  //       chrome.tabs.sendMessage(tab[0].id, {
  //          action: "submit"
  //       }, function (response) {
  //           state.html(response.state)
  //       });
  //   });
  // });
});
