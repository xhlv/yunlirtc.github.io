// chrome.browserAction.onClicked.addListener(function (tab) {
//   chrome.tabCapture.getCapturedTabs((capturedArr) => {
//     // if (!capturedArr.some((capturedTab) => capturedTab.tabId === tab.id && capturedTab.status === 'active')) {
//     //   chrome.tabCapture.capture(
//     //     {
//     //       video: true,
//     //       audio: true,
//     //       videoConstraints: {
//     //         mandatory: {
//     //           chromeMediaSource: 'tab',
//     //           minWidth: 640,
//     //           maxWidth: 1024,
//     //           minHeight: 420,
//     //           maxHeight: 768
//     //         }
//     //       }
//     //     },
//     //     (stream) => {
//     //     }
//     //   );
//     // } else {
//     //   console.log(chrome.tabCapture);
//     //   chrome.tabCapture.onStatusChanged.removeListener(reviveCapture);
//     // }
//   });
// });

// chrome.tabCapture.onStatusChanged.addListener(reviveCapture);

// function reviveCapture(info) {
//   if (info.status === 'stopped' || info.status === 'error') {
//     chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
//       if (info.tabId === tabs[0].id) {
//         chrome.tabCapture.capture({ video: true, audio: true }, (stream) => {
//           console.log(stream, 2222);
//         });
//       }
//     });
//   }
// }

let mediaRecorder = {},
  mediaStream = {};

chrome.runtime.onMessage.addListener(
  //监听扩展程序进程或内容脚本发送请求的请求
  function (message, sender, sendResponse) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const id = tabs[0]?.id;
      if (message === 'yunli-rtc-page-record-start') {
        chrome.tabCapture.capture(
          {
            video: true,
            audio: true,
            videoConstraints: {
              mandatory: {
                chromeMediaSource: 'tab',
                minWidth: 640,
                maxWidth: 1024,
                minHeight: 420,
                maxHeight: 768
              }
            }
          },
          async (stream) => {
            // console.log(stream, 1111);
            const context = new AudioContext();
            // const localStream = await navigator.mediaDevices.getUserMedia({
            //   audio: true
            // });

            if (stream) {
              // alert(stream);
              mediaStream[id] = stream;

              // 复制音轨
              context.createMediaStreamSource(stream).connect(context.destination);
              // context.createMediaStreamSource(localStream).connect(context.destination);
            } else if (!mediaStream[id]) {
              return true;
            }
            // alert('capture succcess...111');
            // if (stream === null) {
            //   chrome.tabs.sendMessage(id, {
            //     error: chrome.runtime.lastError
            //   });
            //   return false;
            // }

            const recordedBlobs = [];
            mediaRecorder[id] = new MediaRecorder(mediaStream[id], {
              videoBitsPerSecond: 2500000,
              mimeType: 'video/webm;codecs=vp9'
            });

            mediaRecorder[id].ondataavailable = (event) => {
              if (event.data && event.data.size > 0) {
                recordedBlobs.push(event.data);
              }
            };

            mediaRecorder[id].onstop = () => {
              const total = recordedBlobs.length;

              recordedBlobs.forEach((o, index) => {
                const superBuffer = new Blob([o], {
                  // type: 'video/webm'
                  type: 'video/mp4'
                });

                // const link = document.createElement('a');
                // link.href = URL.createObjectURL(superBuffer);
                // sendResponse(link.href);
                // postMessage({
                //   name: 'yunli-rtc-page-record-success',
                //   value: link.href
                // });
                // link.setAttribute('download', `test.webm`);
                // link.click();

                // window.open(URL.createObjectURL(superBuffer));

                chrome.tabs.query({ active: true, currentWindow: true }, function (tab) {
                  chrome.tabs.sendMessage(
                    tab[0].id,
                    {
                      name: 'yunli-rtc-page-record-success',
                      value: URL.createObjectURL(superBuffer),
                      index: 0,
                      total: 1
                    },
                    function (response) {}
                  );
                });

                // const file = new File([superBuffer], `page-record-${new Date().getTime()}.mp4`);
                // let fileReader = new FileReader();
                // fileReader.onload = (e) => {
                //   chrome.tabs.query({ active: true, currentWindow: true }, function (tab) {
                //     chrome.tabs.sendMessage(tab[0]?.id, {
                //       name: 'yunli-rtc-page-record-success',
                //       value: e.target.result,
                //       index,
                //       total
                //     });
                //   });
                // };
                // fileReader.readAsDataURL(file);
              });

              // 释放stream流（mediaRecorder中释放也管用，这里可以去掉）
              // mediaStream[id].getTracks().forEach((track) => {
              //   mediaStream[id].removeTrack(track);
              // });

              // 释放AudioContext流
              context.close();
            };

            mediaRecorder[id].start(); // 分片

            // sendResponse(mediaRecorder[id]);
          }
        );
      } else if (message === 'yunli-rtc-page-record-end') {
        // 释放stream流
        if (mediaRecorder[id]) {
          mediaRecorder[id].stream?.getTracks().forEach((track) => {
            track.stop();
          });
          mediaRecorder[id]?.stop();
          mediaRecorder[id] = null;
        }
        // sendResponse(mediaRecorder[id]);
      } else if (message === 'yunli-rtc-page-record-working') {
        // 验证是否正常运行
        chrome.tabs.sendMessage(id, {
          name: 'yunli-rtc-page-record-working',
          value: true
        });
      }
    });
    return true;
  }
);
