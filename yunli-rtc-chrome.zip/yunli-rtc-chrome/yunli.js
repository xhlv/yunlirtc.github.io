// 接收插件中发出的命令
chrome.runtime.onMessage.addListener(
  //监听扩展程序进程或内容脚本发送请求的请求
  function (request, sender, sendResponse) {
    // alert(JSON.stringify(request));
    // alert(document.body.innerHTML);
    const message = request.name;
    if (message == 'yunli-rtc-page-record-success') {
      postMessage(request);
    } else if (message == 'yunli-rtc-page-record-working') {
      postMessage(request);
    }

    // if (message == 'send') {
    //   //   kw.val(request.keyword);
    //   //   sendResponse({ state: '关键词填写成功！' });
    // }
    // if (message == 'submit') {
    //   //   form.submit();
    //   //   sendResponse({ state: '提交成功！' });
    // }
    return true;
  }
);

// chrome.tabs.query({ active: true, lastFocusedWindow: true }).then((tab) => {
//   alert(tab);
// });

// chrome.tabCapture.capture({ video: true }, (stream) => {
//   alert(stream);
//   alert('yunli stream...');
// });

// alert('yunli.js');

// chrome.tabCapture.capture({ video: true }, (stream) => {
//   console.log(stream, 1111);
//   alert(JSON.stringify(tab));
// });

// 接收页面中发出的命令
window.addEventListener('message', (e) => {
  // console.log(e);
  message = e.data;
  if (message == 'yunli-rtc-page-record-start') {
    chrome.runtime.sendMessage('yunli-rtc-page-record-start', (response) => {});
  } else if (message == 'yunli-rtc-page-record-end') {
    chrome.runtime.sendMessage('yunli-rtc-page-record-end', (response) => {});
  } else if (message == 'yunli-rtc-page-record-working') {
    chrome.runtime.sendMessage('yunli-rtc-page-record-working', (response) => {});
  }
  return true;
});
